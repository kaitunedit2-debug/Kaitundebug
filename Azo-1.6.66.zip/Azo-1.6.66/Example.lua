-- Moved to main_example.lua

loadstring(game:HttpGet("https://raw.githubusercontent.com/Footagesus/Azo/refs/heads/main/main_example.lua"))()