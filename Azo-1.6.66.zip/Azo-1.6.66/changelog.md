
## Azo
- Renamed from WindUI to Azo.
- New default "Azo" theme (ink + amber), tighter corner radii, slimmer sidebar and topbar.
- Added build/bundle.js (no darklua needed): `node build/bundle.js`.
# 1.6.66

## Changelog

- added `CodeSize: number`, `CodeTheme: table`, `CanCopied: boolean` and `Height: UDim` to [Code](https://footagesus.github.io/treehub-web/docs/azo/code) element (#91)
- changed PandaDev API url in [Key System](https://footagesus.github.io/treehub-web/docs/azo/keysystem) (#92)
- fixed [Section](https://footagesus.github.io/treehub-web/docs/azo/sections) bg (in custom themes)
- fixed [Colorpicker](https://footagesus.github.io/treehub-web/docs/azo/colorpicker) issue
- fixed `Viewport` bug when u can pinch it outside
- fixed [Window](https://footagesus.github.io/treehub-web/docs/azo/window) Drag with multiple fingers (#79)
- added `ProgressBar` element (#95 by [BitRevenant](https://github.com/BitRevenant)) [Github PR](https://github.com/Footagesus/Azo/pull/95)
- fixed `Dropdown.Locked` (#94 by [BitRevenant](https://github.com/BitRevenant)) [Github PR](https://github.com/Footagesus/Azo/pull/94)
