--[[
    Azo Example 

    example moved to main.client.lua
]]


loadstring(game:HttpGet('https://raw.githubusercontent.com/Footagesus/Azo/refs/heads/main/main.client.lua'))()
