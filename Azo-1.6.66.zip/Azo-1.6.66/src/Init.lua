local Azo = {
	Window = nil,
	Theme = nil,
	Creator = require("./modules/Creator"),
	LocalizationModule = require("./modules/Localization"),
	NotificationModule = require("./components/Notification"),
	Themes = nil,
	Transparent = false,

	TransparencyValue = 0.15,

	UIScale = 1,

	ConfigManager = nil,
	Version = "0.0.0",

	Services = require("./utils/services/Init"),

	OnThemeChangeFunction = nil,

	cloneref = nil,
	UIScaleObj = nil,

	CreateWindow = nil,

	CurrentInput = nil,
}

local cloneref = (cloneref or clonereference or function(instance)
	return instance
end)

Azo.cloneref = cloneref

local HttpService = cloneref(game:GetService("HttpService"))
local Players = cloneref(game:GetService("Players"))
local CoreGui = cloneref(game:GetService("CoreGui"))
local RunService = cloneref(game:GetService("RunService"))
local UserInputService = cloneref(game:GetService("UserInputService"))

function Azo.GenerateGUID()
	return HttpService:GenerateGUID(false)
end

local CurInput = Azo.GenerateGUID()

UserInputService.InputBegan:Connect(function(Input, GameProcessed)
	--[[if GameProcessed then
		return
	end]]

	task.defer(function()
		if
			Input.UserInputType == Enum.UserInputType.MouseButton1
			or Input.UserInputType == Enum.UserInputType.Touch
		then
			if Azo.CurrentInput and Azo.CurrentInput ~= CurInput then
				return
			end

			Azo.CurrentInput = CurInput
			--print(CurInput)
			--Azo.InputStartedOnUI = false
		end
	end)
end)
UserInputService.InputEnded:Connect(function(Input, GameProcessed)
	if Input.UserInputType == Enum.UserInputType.MouseButton1 or Input.UserInputType == Enum.UserInputType.Touch then
		if Azo.CurrentInput and Azo.CurrentInput ~= CurInput then
			return
		end

		Azo.CurrentInput = nil
	end
end)

local LocalPlayer = Players.LocalPlayer or nil

local Package = HttpService:JSONDecode(require("../build/package"))
if Package then
	Azo.Version = Package.version
end

local KeySystem = require("./components/KeySystem")

local Creator = Azo.Creator

local New = Creator.New

--local Tween = Creator.Tween
--local ServicesModule = Azo.Services

local Acrylic = require("./utils/Acrylic/Init")

local ProtectGui = protectgui or (syn and syn.protect_gui) or function() end

local GUIParent = gethui and gethui() or (CoreGui or LocalPlayer:WaitForChild("PlayerGui"))

local UIScaleObj = New("UIScale", {
	Scale = Azo.UIScale,
})

Azo.UIScaleObj = UIScaleObj

Azo.ScreenGui = New("ScreenGui", {
	Name = "Azo",
	Parent = GUIParent,
	IgnoreGuiInset = true,
	ScreenInsets = "None",
	DisplayOrder = -99999,
}, {

	New("Folder", {
		Name = "Window",
	}),
	-- New("Folder", {
	--     Name = "Notifications"
	-- }),
	-- New("Folder", {
	--     Name = "Dropdowns"
	-- }),
	New("Folder", {
		Name = "KeySystem",
	}),
	New("Folder", {
		Name = "Popups",
	}),
	New("Folder", {
		Name = "ToolTips",
	}),
})

Azo.NotificationGui = New("ScreenGui", {
	Name = "Azo/Notifications",
	Parent = GUIParent,
	IgnoreGuiInset = true,
})
Azo.DropdownGui = New("ScreenGui", {
	Name = "Azo/Dropdowns",
	Parent = GUIParent,
	IgnoreGuiInset = true,
})
Azo.TooltipGui = New("ScreenGui", {
	Name = "Azo/Tooltips",
	Parent = GUIParent,
	IgnoreGuiInset = true,
})
ProtectGui(Azo.ScreenGui)
ProtectGui(Azo.NotificationGui)
ProtectGui(Azo.DropdownGui)
ProtectGui(Azo.TooltipGui)

Creator.Init(Azo)

function Azo:SetParent(parent)
	if Azo.ScreenGui then
		Azo.ScreenGui.Parent = parent
	end
	if Azo.NotificationGui then
		Azo.NotificationGui.Parent = parent
	end
	if Azo.DropdownGui then
		Azo.DropdownGui.Parent = parent
	end
	if Azo.TooltipGui then
		Azo.TooltipGui.Parent = parent
	end
end
math.clamp(Azo.TransparencyValue, 0, 1)

local Holder = Azo.NotificationModule.Init(Azo.NotificationGui)

function Azo:Notify(Config)
	Config.Holder = Holder.Frame
	Config.Window = Azo.Window
	--Config.Azo = Azo
	return Azo.NotificationModule.New(Config)
end

function Azo:SetNotificationLower(Val)
	Holder.SetLower(Val)
end

function Azo:SetFont(FontId)
	Creator.UpdateFont(FontId)
end

function Azo:OnThemeChange(func)
	Azo.OnThemeChangeFunction = func
end

function Azo:AddTheme(LTheme)
	Azo.Themes[LTheme.Name] = LTheme
	return LTheme
end

function Azo:SetTheme(Value)
	if Azo.Themes[Value] then
		Azo.Theme = Azo.Themes[Value]
		Creator.SetTheme(Azo.Themes[Value])

		if Azo.OnThemeChangeFunction then
			Azo.OnThemeChangeFunction(Value)
		end

		return Azo.Themes[Value]
	end
	return nil
end

function Azo:GetThemes()
	return Azo.Themes
end
function Azo:GetCurrentTheme()
	return Azo.Theme.Name
end
function Azo:GetTransparency()
	return Azo.Transparent or false
end
function Azo:GetWindowSize()
	return Azo.Window.UIElements.Main.Size
end
function Azo:Localization(LocalizationConfig)
	return Azo.LocalizationModule:New(LocalizationConfig, Creator)
end

function Azo:SetLanguage(Value)
	if Creator.Localization then
		return Creator.SetLanguage(Value)
	end
	return false
end

function Azo:ToggleAcrylic(Value)
	if Azo.Window and Azo.Window.AcrylicPaint and Azo.Window.AcrylicPaint.Model then
		Azo.Window.Acrylic = Value
		Azo.Window.AcrylicPaint.Model.Transparency = Value and 0.98 or 1
		if Value then
			Acrylic.Enable()
		else
			Acrylic.Disable()
		end
	end
end

function Azo:Gradient(stops, props)
	local colorSequence = {}
	local transparencySequence = {}

	for posStr, stop in next, stops do
		local position = tonumber(posStr)
		if position then
			position = math.clamp(position / 100, 0, 1)

			local color = stop.Color
			if typeof(color) == "string" and string.sub(color, 1, 1) == "#" then
				color = Color3.fromHex(color)
			end

			local transparency = stop.Transparency or 0

			table.insert(colorSequence, ColorSequenceKeypoint.new(position, color))
			table.insert(transparencySequence, NumberSequenceKeypoint.new(position, transparency))
		end
	end

	table.sort(colorSequence, function(a, b)
		return a.Time < b.Time
	end)
	table.sort(transparencySequence, function(a, b)
		return a.Time < b.Time
	end)

	if #colorSequence < 2 then
		table.insert(colorSequence, ColorSequenceKeypoint.new(1, colorSequence[1].Value))
		table.insert(transparencySequence, NumberSequenceKeypoint.new(1, transparencySequence[1].Value))
	end

	local gradientData = {
		Color = ColorSequence.new(colorSequence),
		Transparency = NumberSequence.new(transparencySequence),
	}

	if props then
		for k, v in pairs(props) do
			gradientData[k] = v
		end
	end

	return gradientData
end

function Azo:Popup(PopupConfig)
	PopupConfig.Azo = Azo
	return require("./components/popup/Init").new(PopupConfig, Azo.ScreenGui.Popups)
end

Azo.Themes = require("./themes/Init")(Azo, Creator)

Creator.Themes = Azo.Themes

Azo:SetTheme("Azo")
Azo:SetLanguage(Creator.Language)

function Azo:CreateWindow(Config)
	local CreateWindow = require("./components/window/Init")

	if not RunService:IsStudio() and writefile then
		if not isfolder("Azo") then
			makefolder("Azo")
		end
		if Config.Folder then
			makefolder(Config.Folder)
		else
			makefolder(Config.Title)
		end
	end

	Config.Azo = Azo
	Config.Window = Azo.Window
	Config.Parent = Azo.ScreenGui.Window

	if Azo.Window then
		warn("You cannot create more than one window")
		return
	end

	local CanLoadWindow = true

	local Theme = Azo.Themes[Config.Theme or "Azo"]

	--Azo.Theme = Theme
	Creator.SetTheme(Theme)

	local hwid = gethwid or function()
		return Players.LocalPlayer.UserId
	end

	local Filename = hwid()

	if Config.KeySystem then
		CanLoadWindow = false

		local function loadKeysystem()
			KeySystem.new(Config, Filename, function(c)
				CanLoadWindow = c
			end)
		end

		local keyPath = (Config.Folder or "Temp") .. "/" .. Filename .. ".key"

		if Config.KeySystem.KeyValidator then
			if Config.KeySystem.SaveKey and isfile(keyPath) then
				local savedKey = readfile(keyPath)
				local isValid = Config.KeySystem.KeyValidator(savedKey)

				if isValid then
					CanLoadWindow = true
				else
					loadKeysystem()
				end
			else
				loadKeysystem()
			end
		elseif not Config.KeySystem.API then
			if Config.KeySystem.SaveKey and isfile(keyPath) then
				local savedKey = readfile(keyPath)
				local isKey = (type(Config.KeySystem.Key) == "table") and table.find(Config.KeySystem.Key, savedKey)
					or tostring(Config.KeySystem.Key) == tostring(savedKey)

				if isKey then
					CanLoadWindow = true
				else
					loadKeysystem()
				end
			else
				loadKeysystem()
			end
		else
			if isfile(keyPath) then
				local fileKey = readfile(keyPath)
				local isSuccess = false

				for _, i in next, Config.KeySystem.API do
					local serviceData = Azo.Services[i.Type]
					if serviceData then
						local args = {}
						for _, argName in next, serviceData.Args do
							table.insert(args, i[argName])
						end

						local service = serviceData.New(table.unpack(args))
						local success = service.Verify(fileKey)
						if success then
							isSuccess = true
							break
						end
					end
				end

				CanLoadWindow = isSuccess
				if not isSuccess then
					loadKeysystem()
				end
			else
				loadKeysystem()
			end
		end

		repeat
			task.wait()
		until CanLoadWindow
	end

	local Window = CreateWindow(Config)

	Azo.Transparent = Config.Transparent
	Azo.Window = Window

	if Config.Acrylic then
		Acrylic.init()
	end

	-- function Window:ToggleTransparency(Value)
	--     Azo.Transparent = Value
	--     Azo.Window.Transparent = Value

	--     Window.UIElements.Main.Background.BackgroundTransparency = Value and Azo.TransparencyValue or 0
	--     Window.UIElements.Main.Background.ImageLabel.ImageTransparency = Value and Azo.TransparencyValue or 0
	--     Window.UIElements.Main.Gradient.UIGradient.Transparency = NumberSequence.new{
	--         NumberSequenceKeypoint.new(0, 1),
	--         NumberSequenceKeypoint.new(1, Value and 0.85 or 0.7),
	--     }
	-- end

	return Window
end

return Azo
